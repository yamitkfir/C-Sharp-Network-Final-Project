﻿/*

XAML
WindowStyle="None" ResizeMode="NoResize
Closing ="Window_Closing"
<Border BorderThickness="5" BorderBrush="Black" Background="LightGray" Grid.ColumnSpan="4" Grid.RowSpan="5"></Border>


C#

messagebox:
DialogResult result = MessageBox.Show(message, title, MessageBoxButtons.YesNo);  

Monitoring.keyboardMonitoring();
System.Diagnostics.Debug.WriteLine("File does not exist.");

IN CONNECTIONS:
public static String RecieveMSG(String send)
{
    byte[] bytes = new byte[1024];
    String returni;
    try
    {
        // Send the byte-array data through the socket.    
        int bytesSent = sender.Send(Encoding.ASCII.GetBytes(send + "<EOF>"));

        // Receive the response from the remote device.    
        int bytesRec = sender.Receive(bytes);
        returni = Encoding.ASCII.GetString(bytes, 0, bytesRec);

        if (returni == "esc")
        {
            CloseConnection();
            returni = "bye";
        }
    }
    catch (SocketException se)
    {
        returni = "SocketException : " + se.ToString();
    }
    catch (Exception e)
    {
        returni = "Unexpected exception : " + e.ToString();
    }
    return returni;
}

IN HOME: 
 public void RecieveNewAnimalFromWindow(Boolean isNew, string name, string newname) 
{
    //updating the new name of the animal
    int num_of_new_animal = 1;
    if (isNew) {
        num_of_new_animal = num_of_animals1 + 1;
        num_of_animals1 += 1;
    }
    else
        for (int i=0; i < num_of_animals1; i++)
        {
            if (name.Equals(animalnames[i]))
            {
                num_of_new_animal = i+1;
                break;
            }
        }
    names[num_of_new_animal - 1].Content = name;
}

*/